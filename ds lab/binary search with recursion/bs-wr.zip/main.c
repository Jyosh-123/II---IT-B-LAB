/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int recursive_binarysearch(int a[],int low,int high,int key);
int main()
{
    int pos,key;
    int a[10] = {3,6,8,10,14,15,20,30,66,99};
    printf("enter the key value:");
    scanf("%d",&key); 
    pos = recursive_binarysearch(a, 0, 9, key);
    if(pos != -1){
        printf("the element is found at %d",pos);
    }
    else{
        printf("the element  is not found" );
    }
    return 0;
}
int recursive_binarysearch(int a[],int low,int high,int key){
    int mid = 0;
        if(low>high){
            return -1;
        }
         mid = (low+high)/2;
        if (a[mid] == key){
            return mid;
        }
        else if(key < a[mid]){
            recursive_binarysearch(a,low,mid-1,key);
        }
        else{
            recursive_binarysearch(a,mid+1,high,key);
        }
}

