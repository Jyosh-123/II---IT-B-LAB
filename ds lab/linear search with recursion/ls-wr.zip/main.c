/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int recursive_linearsearch(int a[],int key,int index,int n)
{
    int i = 0;
    if(index >= n){
        return 0;
    }
    else if(a[index] == key){
        i = index + 1;
    }
    else{
    return recursive_linearsearch(a , key , index+1 , n);
    }
    return i;
}
int main()
{
    int i,key;
    int n = 10;
    int a[10] = {10,6,8,15,20,3,14,99,66,30};
    printf("enter the key element:");
    scanf("%d",&key);
    i = recursive_linearsearch(a , key , 0 , n);
    if (i != 0)
    {
        printf("element found at %d position",i-1);
    }
    else{
        printf(" element not found");
    }
    return 0;
}

