/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
 int a[10] = {3,6,8,10,14,15,20,30,66,99};
 int low,high,mid,key;
 printf("enter the key value");
 scanf("%d",&key);
 low = 0;
 high = 9;
 mid = 0;
 while(low<=high){
     mid = (low + high)/2;
     if(key < a[mid]){
         high = mid - 1;
     }
     else if(key > a[mid]){
         high = mid + 1;
     }
     else if (key == a[mid]){
         printf("%d is element found",mid);
         break;
     }
 }
 if(low > high){
     printf("element not found");
 }

    return 0;
}
