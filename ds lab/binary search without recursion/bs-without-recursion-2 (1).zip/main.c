/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int binary_search(int[],int);
int main()
{
 int i,key,position;
 int a[10] = {3,6,8,10,14,15,20,30,66,99};
 printf("enter the key value");
 scanf("%d",&key);
 position = binary_search(a,key);
 if (position == -1){
     printf("element not found");
 }
 else{
     printf("%d is element position",position + 1);
 }
 return 0;
}
int binary_search(int a[],int key)
{
    int mid,position, low = 0, high = 9;
 while(low<=high){
     mid = (low + high)/2;
     if(key < a[mid]){
         high = mid - 1;
     }
     else if(key > a[mid]){
         low = mid + 1;
     }
     else if (key == a[mid]){

         break;
     }
 }
 if(low > high)
 return -1;
 return position;
}


