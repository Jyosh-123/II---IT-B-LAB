/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a[10]={10,6,8,15,20,3,14,99,66,30};
    int i=0,key;
    printf("enter the key value :");
    scanf("%d", &key);
    for(i=0;i<10;i++){
        if (a[i]==key)
        {
            printf("%d is element position",i);
            break;
        }
        
    }
    if(i==10){
            printf("element not found");
        
    }

    return 0;
}
