/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
 
void bubble_sort(int [], int);
 
int main()
{
  int a[30], n, c,flag = 0;;
 
  printf("Enter number of elements\n");
  scanf("%d", &n);
 
  printf( "%d\n", n);
 
  for (c = 0; c < n; c++)
    scanf("%d", &a[c]);
    for (c=0;c<n-1;c++)
{
    if(a[c] > a[c+1]){
        flag = 1;
    }
} 
if(flag == 1){

  bubble_sort(a, n);
 
  printf("Sorted list in ascending order:\n");
}
else{
    printf("the array is already sorted\n");
}
  for ( c = 0 ; c < n ; c++ )
     printf("%d\n", a[c]);
 
  return 0;
}
void bubble_sort(int a[], int n)
{
  int c, d, t;
 
  for (c = 0 ; c <  n - 1; c++)
  {
    for (d = 0; d < n - c - 1; d++)
    {
      if (a[d] > a[d+1])
      {
        t         = a[d];
        a[d]   = a[d+1];
        a[d+1] = t;
      }
    }
  }
}
 




