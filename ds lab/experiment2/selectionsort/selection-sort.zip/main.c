/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void selection_sort(int a[],int n);
int main(){
    int a[20],n,i;
    printf("enter the number of elements");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    selection_sort( a , n);
}
void selection_sort(int a[],int n){
    int i,position,j,swap;
    for(i = 0; i < n - 1; i++)
  {
   position=i;
   for(j = i + 1; j < n; j++)
   {
  if(a[position] > a[j])
  position=j;
  }
  if(position != i)
  {
  swap=a[i];
  a[i]=a[position];
  a[position]=swap;
  }
  }
printf("Sorted Array\n");
for(i = 0; i < n; i++)
printf("%d\n", a[i]);
}
  
  