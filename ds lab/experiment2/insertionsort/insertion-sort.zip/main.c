//insertion sort

#include<stdio.h>
void insertion_sort(int a[],int n);
int main(){
    int a[30],i, n;
    printf("enter the n value\n");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    insertion_sort( a , n);
    return 0;
}
void insertion_sort(int a[],int n){
    int i,j,temp;
    for(i=1;i<n;i++){
        temp = a[i];
        for(j=i;j>0 && temp < a[j-1];j--){
            a[j] = a[j-1];
        }
        a[j] = temp;
    }
    for(i=0;i<n;i++){
    printf("%d\n",a[i]);
    }
}

